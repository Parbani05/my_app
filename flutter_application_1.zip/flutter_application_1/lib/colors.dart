import 'package:flutter/material.dart';

const operatorcolor= Color(0xff272727);
const buttoncolor= Color(0xff191919);